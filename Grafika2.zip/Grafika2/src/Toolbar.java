import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.text.DecimalFormat;
import java.util.Objects;

public class Toolbar extends JPanel implements ActionListener, AdjustmentListener {

    JButton negative = new JButton("Negative");
    static String[] comboBoxItems = { "Image 1", "Image 2"};
    static JComboBox cb = new JComboBox(comboBoxItems);

    JScrollBar brightness;
    JPanel brightness_panel = new JPanel();
    JLabel brightness_label = new JLabel("Brightness 0");

    JPanel gamma_panel = new JPanel();
    JButton gamma = new JButton("Gamma (potegowe)");
    JFormattedTextField gamma_n = new JFormattedTextField(new DecimalFormat("#.#"));

    JPanel mixing_panel = new JPanel();
    JButton addition = new JButton("Addition");
    JButton subtractive = new JButton("Substractive");
    JButton difference = new JButton("Difference");
    JButton multiply = new JButton("Multiply");

    public Toolbar() {
        this.setLayout(new GridBagLayout());
        negative.setBackground(Color.white);
        negative.addActionListener(this);
        brightness_panel.setLayout(new BorderLayout(15, 15));
        brightness_panel.add(brightness_label, BorderLayout.NORTH);
        brightness_panel.add(brightness = new JScrollBar(Adjustable.HORIZONTAL, 0, 0, -255, 255), BorderLayout.CENTER);
        brightness.setBlockIncrement(1);
        brightness.addAdjustmentListener(this);
        brightness.setPreferredSize(new Dimension(500, 20));

        JLabel gamma_label = new JLabel("n");

        gamma_n.setColumns(4);
        gamma_label.setLabelFor(gamma_n);
        gamma_n.setValue(0.5D);
        gamma_panel.add(gamma_label);
        gamma_panel.add(gamma_n);
        gamma_panel.add(gamma);
        gamma.addActionListener(this);

        addition.addActionListener(this);
        subtractive.addActionListener(this);
        difference.addActionListener(this);
        multiply.addActionListener(this);
        mixing_panel.add(addition);
        mixing_panel.add(subtractive);
        mixing_panel.add(difference);
        mixing_panel.add(multiply);

        GridBagConstraints gbc = new GridBagConstraints();

        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.weightx = 1;
        gbc.weighty = 1;
        add(cb, gbc);
        gbc.gridx = 1;
        gbc.gridy = 2;
        add(brightness_panel, gbc);
        gbc.gridx = 1;
        gbc.gridy = 3;
        add(negative, gbc);
        gbc.gridx = 1;
        gbc.gridy = 4;
        add(gamma_panel, gbc);
        gbc.gridx = 1;
        gbc.gridy = 5;
        add(mixing_panel, gbc);
    }

    public void adjustmentValueChanged(AdjustmentEvent evt) {
        brightness_label.setText("Brightness " + brightness.getValue());
        if (Objects.equals(Toolbar.cb.getSelectedItem(), "Image 1")) {
            Surface.brighten(Surface.img_1, Surface.img_1_temp, brightness.getValue());
        } else if (Objects.equals(Toolbar.cb.getSelectedItem(), "Image 2")) {
            Surface.brighten(Surface.img_2, Surface.img_2_temp, brightness.getValue());
        }
    }
    public void actionMethod(ActionEvent e) {
        if (e.getSource() == negative) {
            if (Objects.equals(Toolbar.cb.getSelectedItem(), "Image 1")) {
                Surface.negative(Surface.img_1_temp);
            } else if (Objects.equals(Toolbar.cb.getSelectedItem(), "Image 2")) {
                Surface.negative(Surface.img_1_temp);
            }
        }

        if (e.getSource() == gamma) {
            if (Objects.equals(Toolbar.cb.getSelectedItem(), "Image 1")) {
                Surface.gamma(Surface.img_1, Surface.img_1_temp, ((Number)gamma_n.getValue()).floatValue());
            } else if (Objects.equals(Toolbar.cb.getSelectedItem(), "Image 2")) {
                Surface.gamma(Surface.img_2, Surface.img_2_temp, ((Number)gamma_n.getValue()).floatValue());
            }
        }

        if (e.getSource() == addition) {
            if (Objects.equals(Toolbar.cb.getSelectedItem(), "Image 1")) {
                Surface.addition(Surface.img_1, Surface.img_2, Surface.img_1_temp);
            } else if (Objects.equals(Toolbar.cb.getSelectedItem(), "Image 2")) {
                Surface.addition(Surface.img_2, Surface.img_1, Surface.img_2_temp);
            }
        }

        if (e.getSource() == subtractive) {
            if (Objects.equals(Toolbar.cb.getSelectedItem(), "Image 1")) {
                Surface.substraction(Surface.img_1, Surface.img_2, Surface.img_1_temp);
            } else if (Objects.equals(Toolbar.cb.getSelectedItem(), "Image 2")) {
                Surface.substraction(Surface.img_2, Surface.img_1, Surface.img_2_temp);
            }
        }

        if (e.getSource() == difference) {
            if (Objects.equals(Toolbar.cb.getSelectedItem(), "Image 1")) {
                Surface.difference(Surface.img_1, Surface.img_2, Surface.img_1_temp);
            } else if (Objects.equals(Toolbar.cb.getSelectedItem(), "Image 2")) {
                Surface.difference(Surface.img_2, Surface.img_1, Surface.img_2_temp);
            }
        }

        if (e.getSource() == multiply) {
            if (Objects.equals(Toolbar.cb.getSelectedItem(), "Image 1")) {
                Surface.multiply(Surface.img_1, Surface.img_2, Surface.img_1_temp);
            } else if (Objects.equals(Toolbar.cb.getSelectedItem(), "Image 2")) {
                Surface.multiply(Surface.img_2, Surface.img_1, Surface.img_2_temp);
            }
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        actionMethod(e);
    }
}

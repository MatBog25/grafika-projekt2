import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.awt.image.WritableRaster;
import java.io.File;

public class LoadedImage {

    private BufferedImage image;
    private int width;
    private int height;

    LoadedImage() {
        try {
            File input = new File("src/zdjecie.jpg");
            image = ImageIO.read(input);
            width = image.getWidth();
            height = image.getHeight();
        } catch (Exception e) {
            System.out.println("nie znaleziono zdjecia");
        }
    }

    LoadedImage(String path) {
        try {
            File input = new File(path);
            image = ImageIO.read(input);
            width = image.getWidth();
            height = image.getHeight();
        } catch (Exception e) {
            System.out.println("nie znaleziono zdjecia");
        }
    }

    public BufferedImage getImage() {
        return image;
    }

    public int getHeight() {
        return height;
    }

    public int getWidth() {
        return width;
    }
    public void setImage(String path) {
        try {
            File input = new File(path);
            image = ImageIO.read(input);
            width = image.getWidth();
            height = image.getHeight();
        } catch (Exception e) {
            System.out.println("nie znaleziono zdjecia");
        }
    }
}

import java.awt.*;
import javax.swing.*;
import javax.swing.border.LineBorder;

public class Window extends JFrame {

    public Window() {

        this.setLayout(new GridBagLayout());

        initUI();
    }

    private void initUI() {

        GridBagConstraints gbc = new GridBagConstraints();

        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.weightx = 1;
        gbc.weighty = 1;

        add(new Toolbar(), gbc);
        gbc.gridx = 1;
        gbc.gridy = 2;
        add(new Surface(), gbc);

        setTitle("Edytor");
        setSize(800, 600);
        setLocationRelativeTo(null);

        pack();
    }

    public static void main(String[] args) throws Exception {
            Histogram hist = new Histogram();
            hist.wywolanie();
            Maska mask = new Maska();
            mask.maskowanie();


        EventQueue.invokeLater(new Runnable() {

            @Override
            public void run() {
                Window window = new Window();
                window.setVisible(true);
            }
        });
    }
}
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.event.MouseInputAdapter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Objects;

class Surface extends JPanel implements ActionListener {

    JFrame frame = new JFrame();
    boolean mousePressed = false;

    static LoadedImage img_1 = new LoadedImage();
    static LoadedImage img_2 = new LoadedImage("src/zdjecie2.jpg");
    static LoadedImage img_1_temp = new LoadedImage();
    static LoadedImage img_2_temp = new LoadedImage("src/zdjecie2.jpg");

    Timer timer = new Timer(10, this);

    public Surface() {
        this.setBorder(BorderFactory.createLineBorder(Color.green));
        this.setPreferredSize(new Dimension(800, 600));
        MyMouseListener ml = new MyMouseListener();
        addMouseListener(ml);
        addMouseMotionListener(ml);
        timer.start();

//        this.setPreferredSize(new Dimension(img_1.getWidth(), img_1.getHeight()));
        frame.pack();
    }

    private void doDrawing(Graphics g) {

        Graphics2D g2d = (Graphics2D) g;
//        g2d.drawLine(400, 300, 400 + xStep, 300 + yStep);
    }

    @Override
    public void paintComponent(Graphics g) {

        super.paintComponent(g);
        doDrawing(g);

        Graphics2D g2d = (Graphics2D) g;

        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        g2d.setStroke(new BasicStroke(4f));

//        g2d.drawImage(img_1.getImage(), 0, 0, null);

        Dimension d = getSize();
//        g2d.drawImage(img_1.getImage(), 0, 0, d.width, d.height, this);

        if (Objects.equals(Toolbar.cb.getSelectedItem(), "Image 1")) {
            g2d.drawImage(img_1_temp.getImage(), 0, 0, d.width, d.height, this);
        } else if (Objects.equals(Toolbar.cb.getSelectedItem(), "Image 2")) {
            g2d.drawImage(img_2_temp.getImage(), 0, 0, d.width, d.height, this);
        }

        System.out.println(Toolbar.cb.getSelectedItem());

        Toolkit.getDefaultToolkit().sync();
    }

    static public void brighten(LoadedImage img, LoadedImage img_temp, int brightness) {

        int rgb[];
        for(int i = 0; i < img.getWidth(); i++){
            for(int j = 0; j < img.getHeight(); j++){
                rgb = img.getImage().getRaster().getPixel(i, j, new int[3]);
                int red = Truncate(rgb[0] + brightness);
                int green = Truncate(rgb[1] + brightness);
                int blue = Truncate(rgb[2] + brightness);

                int arr[] = { red, green, blue };
                img_temp.getImage().getRaster().setPixel(i, j, arr);
            }
        }
    }

    static public void gamma(LoadedImage img, LoadedImage img_temp, double n) {

        int rgb[];
        for(int i = 0; i < img.getWidth(); i++){
            for(int j = 0; j < img.getHeight(); j++){
                rgb = img.getImage().getRaster().getPixel(i, j, new int[3]);
                double red = rgb[0] / 255.0;
                double green = rgb[1] / 255.0;
                double blue = rgb[2] / 255.0;
                red = Math.pow(red, n);
                green = Math.pow(green, n);
                blue = Math.pow(blue, n);

                int arr[] = {(int) (red * 255), (int) (green * 255), (int) (blue * 255)};
                img_temp.getImage().getRaster().setPixel(i, j, arr);
            }
        }
    }

    static public void addition(LoadedImage img_1, LoadedImage img_2, LoadedImage img_temp) {

        int rgb[];
        int rgb2[];
        int lower_width = Math.min(img_1.getWidth(), img_2.getWidth());
        int lower_height = Math.min(img_1.getHeight(), img_2.getHeight());
        for(int i = 0; i < lower_width; i++){
            for(int j = 0; j < lower_height; j++){
                rgb = img_1.getImage().getRaster().getPixel(i, j, new int[3]);
                rgb2= img_2.getImage().getRaster().getPixel(i, j, new int[3]);
                int red = Truncate(rgb[0] + rgb2[0]);
                int green = Truncate(rgb[1] + rgb2[1]);
                int blue = Truncate(rgb[2] + rgb2[2]);

                int arr[] = { red, green, blue };
                img_temp.getImage().getRaster().setPixel(i, j, arr);
            }
        }
    }

    static public void substraction(LoadedImage img_1, LoadedImage img_2, LoadedImage img_temp) {

        int rgb[];
        int rgb2[];
        int lower_width = Math.min(img_1.getWidth(), img_2.getWidth());
        int lower_height = Math.min(img_1.getHeight(), img_2.getHeight());
        for(int i = 0; i < lower_width; i++){
            for(int j = 0; j < lower_height; j++){
                rgb = img_1.getImage().getRaster().getPixel(i, j, new int[3]);
                rgb2= img_2.getImage().getRaster().getPixel(i, j, new int[3]);
                int red = Truncate(rgb[0] - rgb2[0]);
                int green = Truncate(rgb[1] - rgb2[1]);
                int blue = Truncate(rgb[2] - rgb2[2]);

                int arr[] = { red, green, blue };
                img_temp.getImage().getRaster().setPixel(i, j, arr);
            }
        }
    }

    static public void difference(LoadedImage img_1, LoadedImage img_2, LoadedImage img_temp) {

        int rgb[];
        int rgb2[];
        int lower_width = Math.min(img_1.getWidth(), img_2.getWidth());
        int lower_height = Math.min(img_1.getHeight(), img_2.getHeight());
        for(int i = 0; i < lower_width; i++){
            for(int j = 0; j < lower_height; j++){
                rgb = img_1.getImage().getRaster().getPixel(i, j, new int[3]);
                rgb2= img_2.getImage().getRaster().getPixel(i, j, new int[3]);
                int red = Truncate(Math.abs(rgb[0] - rgb2[0]));
                int green = Truncate(Math.abs(rgb[1] - rgb2[1]));
                int blue = Truncate(Math.abs(rgb[2] - rgb2[2]));

                int arr[] = { red, green, blue };
                img_temp.getImage().getRaster().setPixel(i, j, arr);
            }
        }
    }

    static public void multiply(LoadedImage img_1, LoadedImage img_2, LoadedImage img_temp) {

        int rgb[];
        int rgb2[];
        int lower_width = Math.min(img_1.getWidth(), img_2.getWidth());
        int lower_height = Math.min(img_1.getHeight(), img_2.getHeight());
        for(int i = 0; i < lower_width; i++){
            for(int j = 0; j < lower_height; j++){
                rgb = img_1.getImage().getRaster().getPixel(i, j, new int[3]);
                rgb2= img_2.getImage().getRaster().getPixel(i, j, new int[3]);
                int red = Truncate(rgb[0] * rgb2[0]);
                int green = Truncate(rgb[1] * rgb2[1]);
                int blue = Truncate(rgb[2] * rgb2[2]);

                int arr[] = { red, green, blue };
                img_temp.getImage().getRaster().setPixel(i, j, arr);
            }
        }
    }
    static public void negative(LoadedImage img_temp) {

        int rgb[];
        for(int i = 0; i < img_temp.getWidth(); i++){
            for(int j = 0; j < img_temp.getHeight(); j++){
                rgb = img_temp.getImage().getRaster().getPixel(i, j, new int[3]);
                int red = Truncate(255 - rgb[0]);
                int green = Truncate(255 - rgb[1]);
                int blue = Truncate(255 - rgb[2]);

                int arr[] = { red, green, blue };
                img_temp.getImage().getRaster().setPixel(i, j, arr);
            }
        }
    }
    public static int Truncate(int value)
    {

        if (value < 0) {
            value = 0;
        }
        else if (value > 255) {
            value = 255;
        }
        return value;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == timer) {
            repaint();
        }
    }

    class MyMouseListener extends MouseInputAdapter
    {

        public void mousePressed(MouseEvent e)
        {
            mousePressed = true;
        }

        public void mouseDragged(MouseEvent e)
        {
        }

        public void mouseReleased(MouseEvent e)
        {
            mousePressed = false;
        }
    }
}
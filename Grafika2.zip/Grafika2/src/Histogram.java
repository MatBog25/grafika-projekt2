import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Toolkit;
import java.awt.image.PixelGrabber;

import javax.swing.JFrame;
import javax.swing.JPanel;

class HistoGrab extends JPanel {
    Dimension d;
    Image img;
    int iw, ih;
    int pixels[];
    int w, h;
    int hist[] = new int[256];
    int max_hist = 0;

    public void paint(Graphics gg) {
        d = getSize();
        w = d.width;
        h = d.height;

        gg.setColor(Color.white);
        gg.fillRect(0,0,getWidth(),getHeight());

        try {
            img = Toolkit.getDefaultToolkit().getImage("src/zdjecie.jpg");
            MediaTracker t = new MediaTracker(this);

            t.addImage(img, 0);
            t.waitForID(0);
            iw = img.getWidth(null);
            ih = img.getHeight(null);
            pixels = new int[iw * ih];
            PixelGrabber pg = new PixelGrabber(img, 0, 0, iw, ih, pixels, 0, iw);
            pg.grabPixels();
        } catch (InterruptedException e) {
            System.out.println("Interrupted");
            return;
        }

        for (int i = 0; i < iw * ih; i++) {
            int p = pixels[i];
            int r = 0xff & (p >> 16);
            int g = 0xff & (p >> 8);
            int b = 0xff & (p);
            int y = (int) (.33 * r + .56 * g + .11 * b);
            hist[y]++;
        }
        for (int i = 0; i < 256; i++) {
            if (hist[i] > max_hist)
                max_hist = hist[i];
        }
//        gg.drawImage(img, 0, 0, null);
        int x = (w - 256) / 2;
        int lasty = h - h * hist[0] / max_hist;
        for (int i = 0; i < 256; i++, x++) {
            int y = h - h * hist[i] / max_hist;
            gg.setColor(new Color(i, i, i));
            gg.fillRect(x, y, 1, h);
            gg.setColor(Color.red);
            gg.drawLine(x - 1, lasty, x, y);
            lasty = y;
        }
    }
}

public class Histogram {
    public void wywolanie() {
        JFrame frame = new JFrame();
        frame.add(new HistoGrab());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 400);
        frame.setVisible(true);
    }
}
